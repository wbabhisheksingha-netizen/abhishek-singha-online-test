# Abhishek Singha Online Test

A self-hosted MCQ examination platform with an administrator dashboard, student accounts (capacity enforced at 100), timed exams, CSV question/student imports, automatic marking (+4 correct, -1 incorrect, 0 skipped), and per-exam leaderboard.

## Important deployment note

This is a deployable application source package, not a website already published to the public internet. To make it live, deploy it to a Node.js host and configure a persistent disk. No hosting account or domain was connected when this package was created.

## Run locally

Requirements: Node.js 20+ and npm.

```bash
npm install
cp .env.example .env
# Edit .env and set strong SESSION_SECRET and ADMIN_PASSWORD
npm start
```

Open `http://localhost:3000`. Sign in with `ADMIN_USERNAME` and `ADMIN_PASSWORD` from `.env`.

## Deploy to Render (recommended setup)

1. Create a private Git repository and upload this project.
2. In Render, create a **Web Service** connected to that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables: `NODE_ENV=production`, `SESSION_SECRET` (long random secret), `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and `DATA_DIR=/var/data`.
6. Attach a persistent disk mounted at `/var/data` (SQLite database and sessions are stored there). Without persistent storage, student accounts, exams and results may be lost on redeploy/restart.
7. Deploy and open the generated HTTPS URL. Add a custom domain later if desired.

For a production exam day, use a paid instance with persistent storage, enable backups, test load with 100 concurrent students, and arrange a support contact. SQLite is suitable for a modest single-instance deployment; for larger growth or multiple app instances, migrate to PostgreSQL and a shared session store.

## Admin workflow

1. Log in using the admin account.
2. Create an examination and set its duration.
3. Add MCQs manually or import CSV.
4. Publish the exam. Only published exams appear to students.
5. Register up to 100 students through CSV.
6. Share the website URL and each student's username/password privately.
7. View results and ranks from **Results & ranks**.

### Question CSV format

UTF-8 CSV with these exact headers:

```csv
question,A,B,C,D,correct,explanation
Which organelle is called the powerhouse of the cell?,Nucleus,Mitochondrion,Ribosome,Golgi body,B,It is the major site of ATP production.
```

The `correct` field must be A, B, C or D. Avoid commas inside unquoted CSV cells; quote fields that contain commas or line breaks.

### Student CSV format

```csv
username,name,password
NEET001,Student One,TempPass123
NEET002,Student Two,TempPass456
```

Passwords must be at least 8 characters. Usernames must be unique. The application refuses imports that would exceed 100 registered student accounts.

## Marking and ranking

- Correct: +4
- Incorrect: -1
- Unanswered: 0
- Rank: score descending; earlier submission breaks ties.

## Security / operational checklist before a real exam

- Change all example credentials and use a unique strong `SESSION_SECRET`.
- Keep the admin password private and rotate it if exposed.
- Do not share the CSV answer key with students.
- Use HTTPS (Render provides this on its public service URL).
- Configure persistent storage and backups.
- Run a rehearsal with test student accounts, including expiry, submit, and leaderboard checks.
- Load-test the actual hosting plan with 100 simultaneous sessions before a high-stakes exam.

## Current limitations

This starter release uses SQLite on one application instance. It does not yet include student self-service password reset, email/SMS delivery, question randomization, proctoring, detailed answer explanations/review after submission, or PostgreSQL multi-instance scaling. Add these before using it for high-stakes examinations.
